# elif cv2.waitKey(1) == ord('0'):#
        #     names, rolls, times, l = extract_attendance() #